Hello!
PWP requires Contract Configurator to work, so please install that, or the mod will not do anything (I think)

PWP doesn't require any DLC, but they will enhance your experience.

Regardless, we reccomend the following mods:

1. Module Manager (required, included) I don't exactly know what Module Manager does but I know you need it. :)
2. Kerbal Aircraft eXpansion Continued - adds propellers and engines
3. AirplanePlus - propellers, jets, wings, cockpits, and more.

More contracts will be added if people like the mod.

If you encounter any bugs, please send me a message on discord and I'll fix the problem in the next update.
This is my username Tudor#8762

Thanks for downloading the mod, and please enjoy!
